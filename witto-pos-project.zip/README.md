# Enterprise POS & Inventory Platform

This repository contains the requested scaffolding for an enterprise-level POS platform. It includes real-time stock tracking elements, multi-tier user role layouts, dynamic invoice placeholders, and sales analytics charts.

## Architecture
- **Frontend:** React + Vite, styled with Tailwind CSS for a sharp, corporate interface. Includes `react-chartjs-2` for analytics.
- **Backend:** Node.js + Express API setup to serve real-time metrics.
- **Database Engine:** PostgreSQL (Pre-configured via Docker Compose).

## Execution Instructions

To get the application up and running inside Visual Studio Code:

### 1. Launch the Backend API
Open a terminal in VS Code (`Ctrl + \``) and navigate to the backend directory:
```bash
cd backend
npm install
npm start
```
*The API will start listening on port 5000.*

### 2. Launch the Frontend Interface
Open a second terminal instance in VS Code:
```bash
cd frontend
npm install
npm run dev
```
*Vite will compile the React application and provide a local deployment link (usually `http://localhost:5173`).*

### 3. Initialize the Database (Optional)
If your development environment has Docker installed and you're ready to migrate from the mock data to live SQL queries:
```bash
docker-compose up -d
```
