import React, { useState, useEffect } from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export default function App() {
  const [inventory, setInventory] = useState([]);
  const [salesData, setSalesData] = useState(null);

  useEffect(() => {
    // Fetch from backend
    fetch('http://localhost:5000/api/inventory')
      .then(res => res.json())
      .then(data => setInventory(data))
      .catch(err => console.error("Ensure backend is running", err));

    fetch('http://localhost:5000/api/sales')
      .then(res => res.json())
      .then(data => {
        setSalesData({
          labels: data.labels,
          datasets: [
            {
              label: 'Sales ($)',
              data: data.data,
              backgroundColor: 'rgba(59, 130, 246, 0.8)',
            }
          ]
        });
      })
      .catch(err => console.error("Ensure backend is running", err));
  }, []);

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      {/* Corporate Sidebar */}
      <aside className="w-64 bg-slate-900 text-white flex flex-col shadow-lg z-10">
        <div className="p-6 font-bold text-2xl tracking-wide text-blue-400 border-b border-slate-800">
          WITTO<span className="text-white text-sm font-light ml-1">POS</span>
        </div>
        <nav className="flex-1 px-4 py-6 space-y-2">
          <a href="#" className="block py-2.5 px-4 rounded transition duration-200 bg-blue-600 shadow text-sm font-medium">Dashboard Overview</a>
          <a href="#" className="block py-2.5 px-4 rounded transition duration-200 hover:bg-slate-800 text-slate-300 text-sm">Point of Sale</a>
          <a href="#" className="block py-2.5 px-4 rounded transition duration-200 hover:bg-slate-800 text-slate-300 text-sm">Stock Tracking</a>
          <a href="#" className="block py-2.5 px-4 rounded transition duration-200 hover:bg-slate-800 text-slate-300 text-sm">Dynamic Invoices</a>
          <a href="#" className="block py-2.5 px-4 rounded transition duration-200 hover:bg-slate-800 text-slate-300 text-sm">Role Permissions</a>
        </nav>
        <div className="p-4 border-t border-slate-800 text-xs text-slate-400">
          <p>Multi-Tier Role: <span className="text-blue-400 font-semibold">Admin</span></p>
        </div>
      </aside>

      {/* Main Professional Workspace */}
      <main className="flex-1 overflow-y-auto p-10">
        <header className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-semibold text-slate-800">System Dashboard</h1>
            <p className="text-sm text-slate-500 mt-1">Real-time metrics and inventory control</p>
          </div>
          <button className="bg-slate-900 text-white px-5 py-2.5 rounded shadow hover:bg-slate-800 transition text-sm font-medium">
            + Generate Invoice
          </button>
        </header>

        {/* Analytics Chart */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 mb-8">
          <h2 className="text-lg font-semibold mb-4 text-slate-800">Sales Analytics</h2>
          <div className="h-64">
            {salesData ? <Bar data={salesData} options={{ maintainAspectRatio: false }} /> : <p className="text-slate-400 mt-10 text-center">Awaiting backend connection on port 5000...</p>}
          </div>
        </div>

        {/* Inventory Table */}
        <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
          <h2 className="text-lg font-semibold mb-4 text-slate-800">Real-Time Stock Tracking</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-200">
                  <th className="pb-3 font-medium text-slate-500 uppercase tracking-wider text-xs">SKU</th>
                  <th className="pb-3 font-medium text-slate-500 uppercase tracking-wider text-xs">Product Designation</th>
                  <th className="pb-3 font-medium text-slate-500 uppercase tracking-wider text-xs">Stock Level</th>
                  <th className="pb-3 font-medium text-slate-500 uppercase tracking-wider text-xs">Unit Price</th>
                </tr>
              </thead>
              <tbody>
                {inventory.length > 0 ? inventory.map(item => (
                  <tr key={item.id} className="border-b border-slate-50 hover:bg-slate-50 transition">
                    <td className="py-4 text-slate-500">#{item.id.toString().padStart(4, '0')}</td>
                    <td className="py-4 font-medium text-slate-800">{item.item}</td>
                    <td className="py-4">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${item.stock > 40 ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                        {item.stock} Units
                      </span>
                    </td>
                    <td className="py-4 text-slate-600">${item.price}</td>
                  </tr>
                )) : (
                  <tr><td colSpan="4" className="py-6 text-center text-slate-400">No telemetry data. Ensure Node.js service is operational.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}