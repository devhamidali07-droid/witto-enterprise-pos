const express = require('express');
const cors = require('cors');
const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Mock Inventory Data for Real-Time Stock Tracking
const inventory = [
  { id: 1, item: 'Pro Server Rack', stock: 45, price: 1200 },
  { id: 2, item: 'Cloud Access License', stock: 120, price: 250 },
  { id: 3, item: 'DevOps Tooling Bundle', stock: 30, price: 1500 }
];

// Routes
app.get('/api/inventory', (req, res) => {
  res.json(inventory);
});

app.get('/api/sales', (req, res) => {
  res.json({
    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
    data: [1200, 1900, 3000, 5000, 2400, 3100, 4200]
  });
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});